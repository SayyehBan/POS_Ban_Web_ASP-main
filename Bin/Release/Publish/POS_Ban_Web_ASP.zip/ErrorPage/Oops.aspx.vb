﻿
Partial Class ErrorPage_Oops
    Inherits System.Web.UI.Page

End Class
