﻿
Partial Class ErrorPage_404aspx
    Inherits System.Web.UI.Page

End Class
